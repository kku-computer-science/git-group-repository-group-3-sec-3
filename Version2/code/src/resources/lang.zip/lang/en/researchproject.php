<?php
return [
'Title' => 'Academic Service Project / Research Project',
'Order' => 'Order',
'Year' => 'Year',
'ProjectName' => 'Project Name',
'Detail' => 'Detail',
'ProjectSuper' => 'Project Supervisor',
'Status' => 'Status',
'Duration' => 'Duration',
'ResearchType' => 'Research Type',
'Funding_Agency' => 'Funding Agency',
'Responsible_agency' => 'Responsible Agency',
'Budget' => 'Project Budget',
'Baht' => 'Baht',
'Request' => 'Request',
'On_going' => 'In progress',
'Completed' => 'Completed',
'To' => 'to',
'date_format' => 'j F Y',

];