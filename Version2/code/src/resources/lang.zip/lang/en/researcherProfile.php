<?php
return [

'serach'=>'Search',
'ph'=>'Research interests',
'no'=>'No.',
'year'=>'Year',
'papername'=>'Paper Name',
'author'=>'Author',
'documenttype'=>'Document Type',
'page'=>'Page',
'journals'=>'Journals/Transactions',
'cite'=>'Citations',
'doi'=>'Doi',
'source'=>'Source',
'summary'=>'Summary',
'book'=>'Book',
'other'=>'Other Academic Works',
'email'=>'email',
'number'=>'Number',
'name'=>'Name',
'pub'=>'publication',
'export'=>'Export To Exel',
'bookName'=>'Name',
'placePub'=>'Place of Publication',
'type'=>'Type',
'date'=>'Registration Date',
'numdata'=>'Registration Number',

];

