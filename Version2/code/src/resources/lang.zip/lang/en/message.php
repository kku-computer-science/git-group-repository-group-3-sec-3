<?php
return [
'Home' => 'Home',
'Researchers' => 'Researchers',
'ResearchProj' => 'Research Project',
'ResearchGroup' => 'Research Group',
'Report' => 'Reports',
'details' =>'More details',
'expertise' => 'Research interests',
'publications' => 'Publications (In the Last 5 Years)',
'education'=>'Education',
'publications2' => 'Publications',
'login'=>'Login',
];