<?php
return [
'labSuper' => 'Laboratory Supervisor ',
'student' => 'Student',

];

