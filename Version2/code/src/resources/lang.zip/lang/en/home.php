<?php
return [
'ref' => 'ref',
'references' => 'Reference',
'close' => 'Close',
'summary' => 'SUMMARY',
'graphtext' => 'Report the total number of articles (5 years : cumulative)',
'year' => 'year',
'number' => 'Number',
'before' => 'Before ',
];

