<?php
return [
'researchGroup' => 'Research Group',
'labSuper' => 'Laboratory Supervisor ',

];

