<?php
return [
'res' => 'Researchers',
'serach'=>'Search',
'ph'=>'Research interests',

];

