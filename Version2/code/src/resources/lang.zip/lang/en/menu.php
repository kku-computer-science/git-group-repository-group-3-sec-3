return [
    'researchers' => 'Researchers',
    'computer_science' => 'Computer Science',
    'information_technology' => 'Information Technology',
    'geo_informatics' => 'Geo-Informatics',
    'artificial_intelligence' => 'Artificial Intelligence',
    'cyber_security' => 'Cyber Security',
];
