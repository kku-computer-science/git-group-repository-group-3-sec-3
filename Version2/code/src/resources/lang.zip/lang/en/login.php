<?php
return [
    'title' => 'Account Login',
    'username' => 'Username',
    'password' => 'Password',
    'remember' => 'Remember Me',
    'forgot_password' => ' If you forgot your password, please contact the administrator.',
    'use_kku_mail' => 'Use KKU-Mail to log in.',
    'first_time_login' => 'For first-time student login, use student ID.',
    'login_failed' => 'Login Failed: Your user ID or password is incorrect',
];
