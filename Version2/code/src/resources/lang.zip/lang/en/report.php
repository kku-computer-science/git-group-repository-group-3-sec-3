<?php
return [
'StatReport' => 'Total number of articles statistics for 5 years',
'StatRef' => 'Statistics on the number of articles cited',
'Source' => 'Source',
'date_format' => 'j F Y',

];