<?php
return [
    'labSuper' => '实验室负责人',
    'student' => '学生',
];

