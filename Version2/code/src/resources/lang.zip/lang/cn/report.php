<?php
return [
    'StatReport' => '5年文章总数统计',
    'StatRef' => '引用文章数量统计',
    'Source' => '来源',
    'date_format' => 'Y年j月d日',
];