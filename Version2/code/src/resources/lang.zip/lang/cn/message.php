<?php
return [
'Home' => '家',
'Researchers' => '研究员',
'ResearchProj' => '研究员',
'ResearchGroup' => '研究小组',
'Report' => '报告',
'details' =>'更多详情',
'expertise' =>'技能',
'publications' => '出版物 （5 年）',
'education'=>'教育',
'publications2' => '出版物',
'login'=>'登录',
];