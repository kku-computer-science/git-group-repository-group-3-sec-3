<?php
return [
    'researchGroup' => '研究小组',
    'labSuper' => '实验室负责人',
];


