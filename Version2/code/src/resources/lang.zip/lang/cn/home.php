<?php
return [
'ref' => '引用',
'references' => '引用',
'close' => '关闭',
'summary' => '总结',
'graphtext' => '报告总文章数 (5年累计)',
'year' => '年',
'number' => '文章数量',
'before' => '一年前 ',
];