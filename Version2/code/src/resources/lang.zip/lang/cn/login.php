<?php
return [
    'title' => '账户登录',
    'username' => '用户名',
    'password' => '密码',
    'remember' => '记住我',
    'forgot_password' => ' 如果忘记密码，请联系管理员。',
    'use_kku_mail' => '使用 KKU-Mail 登录。',
    'first_time_login' => '首次登录的学生，请使用学号。',
    'login_failed' => '登录失败：您的用户 ID 或密码不正确',
];
