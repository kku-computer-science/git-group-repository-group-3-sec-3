<?php
return [
    'res' => '研究人员',
    'serach' => '搜索',
    'ph' => '研究兴趣',
];

