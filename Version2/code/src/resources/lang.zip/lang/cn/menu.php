return [
    'researchers' => '研究人员',
    'computer_science' => '计算机科学',
    'information_technology' => '信息技术',
    'geo_informatics' => '地理信息学',
    'artificial_intelligence' => '人工智能',
    'cyber_security' => '网络安全',
];
