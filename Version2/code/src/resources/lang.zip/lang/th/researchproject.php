<?php
return [
'Title' => 'โครงการบริการวิชาการ/ โครงการวิจัย',
'Order' => 'ลำดับ',
'Year' => 'ปี',
'ProjectName' => 'ชื่อโครงการ',
'Detail' => 'รายละเอียด',
'ProjectSuper' => 'ผู้รับผิดชอบโครงการ',
'Status' => 'สถานะ',
'Duration' => 'ระยะเวลาโครงการ',
'ResearchType' => 'ประเภทของทุนวิจัย',
'Funding_Agency' => 'หน่วยงานที่สนันสนุนทุน',
'Responsible_agency' => 'หน่วยงานที่รับผิดชอบ',
'Budget' => 'งบประมาณที่ได้รับจัดสรร',
'Baht' => 'บาท',
'Request' => 'ยื่นขอ',
'On_going' => 'ดำเนินการ',
'Completed' => 'ปิดโครงการ',
'To' => 'ถึง',
'date_format' => 'j F Y', 



];

