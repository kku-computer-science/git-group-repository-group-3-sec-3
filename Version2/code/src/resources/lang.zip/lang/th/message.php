<?php
return [
'Home' => 'หน้าแรก',
'Researchers' => 'ผู้วิจัย',
'ResearchProj' => 'โครงการวิจัย',
'ResearchGroup' => 'กลุ่มวิจัย',
'Report' => 'รายงาน',
'details' =>'รายละเอียดเพิ่มเติม',
'expertise' =>'ความเชี่ยวชาญ',
'publications' => 'ผลงานตีพิมพ์ (5 ปี ย้อนหลัง)',
'education'=>'การศึกษา',
'publications2' => 'ผลงานตีพิมพ์',
'login'=>'เข้าสู่ระบบ',
];

