<?php
return [
'labSuper' => 'หัวหน้าห้องปฏิบัติการ',
'student' => 'นักศึกษา',

];

