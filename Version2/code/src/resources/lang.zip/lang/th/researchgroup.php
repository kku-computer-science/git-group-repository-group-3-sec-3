<?php
return [
'researchGroup' => 'กลุ่มวิจัย',
'labSuper' => 'หัวหน้าห้องปฏิบัติการ',

];

