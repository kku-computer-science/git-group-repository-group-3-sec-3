return [
    'researchers' => 'นักวิจัย',
    'computer_science' => 'วิทยาการคอมพิวเตอร์',
    'information_technology' => 'เทคโนโลยีสารสนเทศ',
    'geo_informatics' => 'ภูมิสารสนเทศศาสตร์',
    'artificial_intelligence' => 'ปัญญาประดิษฐ์',
    'cyber_security' => 'ความมั่นคงปลอดภัยไซเบอร์',
];
